class MainNote extends HTMLElement {
  constructor() {
      super();
      this.attachShadow({ mode: "open" });
      this.shadowRoot.innerHTML = this.template();
      this.notesListElement = this.shadowRoot.querySelector("#notesList");
  }

  connectedCallback() {
      this.loadNotes();
  }

  template() {
      return `
      <style>
          .mainNote h1 {
              display: flex;
              justify-content: end;
              align-items: center;
              padding-right: 5rem;
          }
          .list {
              display: grid;
              grid-template-columns: repeat(auto-fit, minmax(300px, 1fr));
              gap: 1.5rem;
              padding: 2rem;
              margin: 0 auto;
              max-width: 1400px;
              box-sizing: border-box;
          }
          .list > * {
              height: auto;
              min-height: 100px;
              padding: 1rem;
              border: 1px solid #333;
              border-radius: 1rem;
              box-shadow: 0 2px 4px rgba(0, 0, 0, 0.1);
              position: relative;
          }
          .list > :nth-child(odd) { background-color: #bafcff; }
          .list > :nth-child(even) { background-color: #ff8c8c; }
          .delete-btn {
              position: absolute;
              top: 10px;
              right: 10px;
              background: red;
              color: white;
              border: none;
              padding: 5px;
              cursor: pointer;
              border-radius: 5px;
          }
      </style>
      <form class="mainNote">
          <h1>NotesApp</h1>
          <div id="notesList" class="list"></div>
      </form>`;
  }

  loadNotes() {
      const notes = JSON.parse(localStorage.getItem("notesData")) || [];
      renderNotes(notes, this.notesListElement); 
  }
}

export function renderNotes(notes, container) {
  if (!container) return; 
  container.innerHTML = ""; 

  notes.forEach((note) => {
      const noteElement = document.createElement("div");
      noteElement.setAttribute("data-noteid", note.id);
      noteElement.innerHTML = `
            <h3>${note.title}</h3>
            <p>${note.body}</p>

          <small>Created at: ${new Date(note.createdAt).toLocaleString()}</small>
          <button class="delete-btn" data-id="${note.id}">Hapus</button>
      `;

      noteElement.querySelector(".delete-btn").addEventListener("click", () => {
          document.dispatchEvent(new CustomEvent("deleteNote", { detail: note.id }));
      });

      container.append(noteElement);
  });
}

if (!customElements.get("main-note")) {
    customElements.define("main-note", MainNote);
}
export default MainNote;

