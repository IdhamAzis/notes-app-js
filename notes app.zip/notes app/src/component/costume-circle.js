class CustomCircles extends HTMLElement {
  constructor() {
      super();
      this.attachShadow({ mode: "open" });
  }

  static get observedAttributes() {
      return ['color1', 'color2']; 
  }

  attributeChangedCallback(name, oldValue, newValue) {
      if (name === 'color1' || name === 'color2') {
          this.style.setProperty(`--${name}`, newValue);
      }
  }

  connectedCallback() {
      this.shadowRoot.innerHTML = `
      <style>
          .circle {
              position: fixed;  
              top: 0;
              right: 0;
              width: 20rem;
              height: 20rem;
              z-index: -1;  
          }
          .circle1 {  
              position: absolute;
              bottom: 5rem;
              right: 0rem;
              width: 20rem;
              height: 20rem;
              border-radius: 100%;
              background-color: #FF8C8C; 
          }
          .circle2 {
              position: absolute;
              bottom: 0rem;
              left: 10rem;  
              width: 20rem;
              height: 20rem;
              border-radius: 100%;
              background-color:  #8CFBFF;
              mix-blend-mode: multiply;
          }
      </style>
      <div class="circle">
          <div class="circle1"></div>
          <div class="circle2"></div>
      </div>
      `;
      //background-color: var(--color1, #FF8C8C); gunakan itu untuk mengetes warna yg ditetapkan di tml berfungsi 
      // background-color: var(--color2, #8CFBFF); gunakan itu untuk mengetes warna yg ditetapkan di tml berfungsi
  }
}

if (!customElements.get("custom-circles")) {
    customElements.define("custom-circles", CustomCircles);
}
