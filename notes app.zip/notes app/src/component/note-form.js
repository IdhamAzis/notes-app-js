
class NoteForm extends HTMLElement {
    constructor() {
        super();

        this.attachShadow({ mode: "open" });

        this.shadowRoot.innerHTML = `
        <style>
        #noteForm {
          margin: 4rem auto;
          display: flex;
          flex-direction: column;
          justify-content: center;
          align-items: center;
          max-width: 400px;
          border: 1px solid #ccc;
          border-radius: 2rem;
          background-color: rgba(221, 196, 196, 0.39);
        }

        .title {
          display: flex;
          flex-direction: column;
          justify-content: center;
          align-items: center;
          background-color: #FF8C8C;
          width: 20rem;
          height: 7rem;
          border-radius: 50%;
        }

        .title input {
          border: none;
          background-color: transparent;
          outline: none;
          border-bottom: 1px solid #555;
        }

        .body {
          display: flex;
          flex-direction: column;
          justify-content: center;
          align-items: center;
          width: 20rem; 
          height: 17rem; 
          background-color: #a7f6ff;
          border-radius: 50%; 
          padding: 10px; 
          box-sizing: border-box; 
          margin-bottom: 1rem;
        }

        .body textarea {
          width: 10rem; 
          height: 10rem; 
          background: repeating-linear-gradient(
            transparent 0px,
            transparent 19px,
            #333 20px
          ); 
          border: none; 
          outline: none; 
          resize: none; 
          font-family: Arial, sans-serif; 
          font-size: 14px; 
          line-height: 20px; 
          color: #333; 
        }

        .btn-submit {
          width: 10rem;
          height: 2rem;
          border-radius: 20px;
          font-size: 1rem;
          font-weight: bold;
          margin-bottom: 1rem;
          color: #505050; 
          border: 2px solid #D6D6D6; 
          box-shadow: 0px 3px 5px rgba(0, 0, 0, 0.2); 
          background-color: #E8E8E8; 
        }

        .btn-submit:hover {
          cursor: pointer;
          background-color: #D6D6D6;
        }

        .error {
          color: red;
          font-size: 12px;
        }

        </style>

        <form id="noteForm">
        <h2>Create New Note</h2>
        <div class="title">
            <label for="title">Title:</label>
            <input type="text" id="title" name="title" placeholder="" required><br>
            <div id="titleError" class="error"></div>
        </div>

        <div class="body">
            <textarea id="body" name="body" placeholder="" rows="1" required></textarea><br>
            <div id="bodyError" class="error"></div>
        </div>

        <button type="submit" class="btn-submit">Done</button>
        </form>
        `;

        this.noteForm = this.shadowRoot.querySelector('#noteForm');
        this.titleInput = this.shadowRoot.querySelector('#title');
        this.bodyInput = this.shadowRoot.querySelector('#body');
        this.titleError = this.shadowRoot.querySelector('#titleError');
        this.bodyError = this.shadowRoot.querySelector('#bodyError');

        // untuk form submit dan validasi input ketika membuat note baru
        this.noteForm.addEventListener('submit', (event) => this.handleFormSubmit(event));
        this.titleInput.addEventListener('input', () => this.validateTitle());
        this.bodyInput.addEventListener('input', () => this.validateBody());
    }

    connectedCallback() {
        console.log('NoteForm connected!');
    }

    validateTitle() {
        const title = this.titleInput.value;
        if (!title) {
            this.titleError.textContent = "judul tidak boleh kosong!!";
        } else {
            this.titleError.textContent = "";

        }
    }

    validateBody() {
        const body = this.bodyInput.value;
        if (!body) {
            this.bodyError.textContent = "Body masih kosong";
        } else {
            this.bodyError.textContent = "";
        }
    }

    handleFormSubmit(event) {
      event.preventDefault();
  
      const title = this.titleInput.value;
      const body = this.bodyInput.value;
  
      if (!title || !body) {
          alert("Judul atau body tidak boleh kosong!!");
          return;
      }
  
      const newNote = {
          title: title,
          body: body,
      };
  
        fetch("https://notes-api.dicoding.dev/v2/notes", { 
          method: "POST",
          headers: {
              "Content-Type": "application/json",
          },
          body: JSON.stringify(newNote),
      })
      .then(response => response.json())
      .then(data => {
          console.log("Note berhasil ditambahkan!", data);
  
       
          this.titleInput.value = "";
          this.bodyInput.value = "";
  
          document.dispatchEvent(new CustomEvent("noteAdded", { detail: newNote }));
      })
      .catch(error => console.error("Error:", error));
  }
  
  
  fetchNotes() {
      fetch("https://notes-api.dicoding.dev/v2/notes")
      .then(response => response.json())
      .then(notes => {
          document.dispatchEvent(new CustomEvent("notesUpdated", { detail: notes }));
      })
      .catch(error => console.error("Gagal mengambil data:", error));
  }
}

if (!customElements.get("note-form")) {
  customElements.define("note-form", NoteForm);
}

