export const apiUrl = "https://notes-api.dicoding.dev/v2/notes";
export async function getNotes() {
    try {
        const response = await fetch(apiUrl, { cache: "no-store" });
        if (!response.ok) throw new Error("Gagal mendapatkan catatan");
        const result = await response.json();
        return result.data;
    } catch (error) {
        console.error("Error fetching notes:", error);
        return [];
    }
}
export async function createNote({ title, body }) {
    try {
        const response = await fetch(apiUrl, {
            method: "POST",
            headers: { "Content-Type": "application/json" },
            body: JSON.stringify({ title, body })
        });
        if (!response.ok) throw new Error("Gagal membuat catatan");
        return (await response.json()).data;
    } catch (error) {
        console.error("Error creating note:", error);
    }
}
export async function deleteNote(noteId) {
    try {
        const response = await fetch(`${apiUrl}/${noteId}`, { method: "DELETE" });

        if (!response.ok) throw new Error("Gagal menghapus catatan");

        const result = await response.json();
        console.log(result.message); 

        return true; 
    } catch (error) {
        console.error("Error deleting note:", error);
        return false; 
    }
}
