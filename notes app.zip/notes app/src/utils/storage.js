const STORAGE_KEY = "notes";
export function loadNotesFromStorage() {
    return JSON.parse(localStorage.getItem(STORAGE_KEY)) || [];
}
export function saveNotesToStorage(notes) {
    localStorage.setItem(STORAGE_KEY, JSON.stringify(notes));
}