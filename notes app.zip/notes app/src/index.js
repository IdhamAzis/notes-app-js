import './style/style.css';
import "./component/main-note.js";
import "./component/note-form.js";
import "./component/costume-circle.js";
import { getNotes, createNote, deleteNote } from "./utils/api.js";
import { loadNotesFromStorage, saveNotesToStorage } from "./utils/storage.js";
import { renderNotes } from "./component/main-note.js";
import "./component/loading.js";


document.addEventListener("DOMContentLoaded", async () => {
    let notes = loadNotesFromStorage();
    const notesContainer = document.querySelector("main-note").shadowRoot.querySelector("#notesList");
    renderNotes(notes, notesContainer);

    const apiNotes = await getNotes();
    notes = [...apiNotes, ...notes];
    saveNotesToStorage(notes);
    renderNotes(notes, notesContainer); 
});

document.addEventListener("addNote", async (event) => {
    const newNote = await createNote(event.detail);
    const notes = [...loadNotesFromStorage(), newNote];
    saveNotesToStorage(notes);

    const notesContainer = document.querySelector("main-note").shadowRoot.querySelector("#notesList");
    renderNotes(notes, notesContainer); 
});

document.addEventListener("deleteNote", async (event) => {
    await deleteNote(event.detail);
    
    let notes = loadNotesFromStorage();
    notes = notes.filter(note => note.id !== event.detail);
    saveNotesToStorage(notes);

    const notesContainer = document.querySelector("main-note").shadowRoot.querySelector("#notesList");
    renderNotes(notes, notesContainer); 
});

async function fetchAndRenderNotes() {
    const apiNotes = await getNotes(); 
    const localNotes = loadNotesFromStorage(); 

    // Hapus catatan duplikat berdasarkan ID
    const mergedNotes = [...apiNotes, ...localNotes].reduce((acc, note) => {
        if (!acc.some(existingNote => existingNote.id === note.id)) {
            acc.push(note);
        }
        return acc;
    }, []);

    saveNotesToStorage(mergedNotes);

    const notesContainer = document.querySelector("main-note").shadowRoot.querySelector("#notesList");
    renderNotes(mergedNotes, notesContainer);
}


// Jalankan pertama kali saat DOM siap
document.addEventListener("DOMContentLoaded", async () => {
    let localNotes = loadNotesFromStorage();
    const loadingElement = document.createElement("loading-indicator");
    document.body.appendChild(loadingElement); 

    try {
        const apiNotes = await getNotes();

        // Filter agar data dari API tidak duplikat dengan yang ada di localStorage
        const uniqueNotes = apiNotes.filter(apiNote => 
            !localNotes.some(localNote => localNote.id === apiNote.id)
        );

        // Gabungkan data unik dari API dan localStorage
        const allNotes = [...localNotes, ...uniqueNotes];

        saveNotesToStorage(allNotes);
        renderNotes(allNotes);
    } catch (error) {
        console.error("Gagal mengambil data:", error);
    } setTimeout(() => {
        document.body.removeChild(loadingElement);
    }, 1000);
    },
); 

    await fetchAndRenderNotes();
    setInterval(fetchAndRenderNotes, 5000); 
